
from django.shortcuts import render
from django.http import HttpResponse
from .models import VisitorCount

def home(request):
    # Retrieve the visitor count from the database
    count_obj, created = VisitorCount.objects.get_or_create(id=1)
    count_obj.count += 1
    count_obj.save()

    # Pass the count to the template
    context = {'count': count_obj.count}
    return render(request, 'home.html', context)
